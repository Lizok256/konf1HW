import unittest
import os
import tempfile
import shutil

class TestEmulatorCommands(unittest.TestCase):
    def __init__(self):
        self.current_path = tempfile.mkdtemp()

    def ls(self):
        return os.listdir(self.current_path)

    def cd(self, path):
        new_path = os.path.join(self.current_path, path)
        if os.path.isdir(new_path):
            self.current_path = new_path
        else:
            raise FileNotFoundError(f"Directory '{path}' not found")

    def rmdir(self, path):
        dir_path = os.path.join(self.current_path, path)
        if os.path.isdir(dir_path):
            os.rmdir(dir_path)
        else:
            raise FileNotFoundError(f"Directory '{path}' not found")

    def du(self):
        total_size = 0
        for dirpath, dirnames, filenames in os.walk(self.current_path):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                total_size += os.path.getsize(fp)
        return total_size


class TestEmulatorCommands(unittest.TestCase):
    def setUp(self):
        self.fs = TestEmulatorCommands()
        os.mkdir(os.path.join(self.fs.current_path, 'test_dir'))
        with open(os.path.join(self.fs.current_path, 'file1.txt'), 'w') as f:
            f.write('Hello, world!')

    def test_ls(self):
        output = self.fs.ls()
        self.assertIn('test_dir', output)
        self.assertIn('file1.txt', output)

    def test_cd(self):
        self.fs.cd('test_dir')
        output = self.fs.ls()
        self.assertEqual(output, [])  # Папка test_dir должна быть пустой

        # Проверка на ошибку
        with self.assertRaises(FileNotFoundError):
            self.fs.cd('non_existing_dir')

    def test_rmdir(self):
        self.fs.rmdir('test_dir')
        output = self.fs.ls()
        self.assertNotIn('test_dir', output)

        # Проверка на ошибку
        with self.assertRaises(FileNotFoundError):
            self.fs.rmdir('non_existing_dir')

    def test_du(self):
        size = self.fs.du()
        self.assertGreater(size, 0)  # Размер всего содержимого должен быть больше 0

    def tearDown(self):
        shutil.rmtree(self.fs.current_path)


if __name__ == '__main__':
    unittest.main()